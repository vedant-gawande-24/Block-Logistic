import React, { useState, useEffect, useRef } from 'react';
import { LayoutDashboard, PackagePlus, Box, Activity, Sun, Moon, Wifi, Wallet, Users, MessageSquare, Send, X, Menu, LogOut } from 'lucide-react';
import { chatWithSupplyChain } from '../services/geminiService';

interface LayoutProps {
  children: React.ReactNode;
  activePage: string;
  onNavigate: (page: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activePage, onNavigate }) => {
  const [isDark, setIsDark] = useState(true);
  const [walletConnected, setWalletConnected] = useState(false);
  const [role, setRole] = useState('Shipper');
  
  // Mobile Menu State
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Chat State
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<{sender: 'user'|'bot', text: string}[]>([
    {sender: 'bot', text: 'Hello! I am your supply chain assistant. Ask me about your shipments.'}
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
      setIsDark(false);
    } else {
      setIsDark(true);
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  useEffect(() => {
    if(chatOpen && chatEndRef.current) {
        chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, chatOpen]);

  const toggleTheme = () => setIsDark(!isDark);

  const handleWalletConnect = () => {
    // Simulate connection
    setWalletConnected(true);
  };

  const handleSendMessage = async () => {
    if(!chatInput.trim()) return;
    const userMsg = chatInput;
    setMessages(prev => [...prev, {sender: 'user', text: userMsg}]);
    setChatInput('');
    setChatLoading(true);

    // Call AI
    const reply = await chatWithSupplyChain([], userMsg);
    setMessages(prev => [...prev, {sender: 'bot', text: reply}]);
    setChatLoading(false);
  };

  const handleNavClick = (page: string) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen flex text-body font-sans selection:bg-accent selection:text-white transition-colors duration-300">
      
      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-[60] md:hidden">
            <div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
              onClick={() => setMobileMenuOpen(false)}
            ></div>
            <div className="absolute left-0 top-0 bottom-0 w-[80%] max-w-[300px] bg-surface backdrop-blur-xl border-r border-borderMain p-6 shadow-2xl animate-in slide-in-from-left duration-300 flex flex-col">
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center space-x-2 text-accent">
                        <Box size={24} />
                        <h1 className="text-xl font-bold tracking-tight text-body">BlockLogistics</h1>
                    </div>
                    <button onClick={() => setMobileMenuOpen(false)} className="text-muted hover:text-body">
                        <X size={24} />
                    </button>
                </div>
                
                <div className="flex-1 space-y-2">
                    <NavButton 
                        active={activePage === 'dashboard'} 
                        onClick={() => handleNavClick('dashboard')}
                        icon={<LayoutDashboard size={20} />}
                        label="Dashboard"
                    />
                    <NavButton 
                        active={activePage === 'create'} 
                        onClick={() => handleNavClick('create')}
                        icon={<PackagePlus size={20} />}
                        label="New Shipment"
                    />
                    <NavButton 
                        active={activePage === 'tracking'} 
                        onClick={() => handleNavClick('tracking')}
                        icon={<Activity size={20} />}
                        label="Live Tracking"
                    />
                </div>

                <div className="pt-6 border-t border-borderMain/50 space-y-4">
                     <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-inputBg/50 border border-borderMain/50">
                        <div className="flex items-center gap-2 text-sm text-muted">
                            <Users size={16} />
                            <span className="text-xs font-bold uppercase">Role</span>
                        </div>
                        <select 
                            value={role} 
                            onChange={(e) => setRole(e.target.value)}
                            className="bg-transparent text-xs font-bold text-accent outline-none text-right cursor-pointer dark:bg-inputBg"
                        >
                            <option className="dark:bg-darker">Shipper</option>
                            <option className="dark:bg-darker">Carrier</option>
                            <option className="dark:bg-darker">Recipient</option>
                        </select>
                    </div>

                    <button 
                        onClick={handleWalletConnect}
                        className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-bold transition-all ${
                            walletConnected 
                            ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' 
                            : 'bg-primary text-white shadow-lg shadow-primary/20'
                        }`}
                    >
                        <Wallet size={16} />
                        {walletConnected ? '0x71...9A2' : 'Connect Wallet'}
                    </button>

                    <button 
                        onClick={toggleTheme}
                        className="w-full flex items-center justify-between px-4 py-3 rounded-lg bg-inputBg border border-borderMain/50 text-muted hover:text-body transition-all text-sm"
                    >
                        <span className="flex items-center gap-2">
                            {isDark ? <Moon size={16} /> : <Sun size={16} />}
                            {isDark ? 'Dark Mode' : 'Light Mode'}
                        </span>
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside className="w-64 bg-surface backdrop-blur-xl border-r border-borderMain flex flex-col fixed h-full z-20 hidden md:flex transition-colors duration-300 shadow-xl shadow-black/5">
        <div className="p-6 border-b border-borderMain/50">
          <div className="flex items-center space-x-3 text-accent mb-1">
            <div className="p-2 bg-accent/10 rounded-lg">
              <Box size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-body bg-clip-text text-transparent bg-gradient-to-r from-body to-muted">BlockLogistics</h1>
          </div>
          <div className="flex items-center gap-2 mt-3 px-1">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${walletConnected ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${walletConnected ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
            </span>
            <p className="text-[10px] text-muted font-mono tracking-wider uppercase">
                {walletConnected ? 'Mainnet: Connected' : 'Wallet Disconnected'}
            </p>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <NavButton 
            active={activePage === 'dashboard'} 
            onClick={() => onNavigate('dashboard')}
            icon={<LayoutDashboard size={20} />}
            label="Dashboard"
          />
          <NavButton 
            active={activePage === 'create'} 
            onClick={() => onNavigate('create')}
            icon={<PackagePlus size={20} />}
            label="New Shipment"
          />
          <NavButton 
            active={activePage === 'tracking'} 
            onClick={() => onNavigate('tracking')}
            icon={<Activity size={20} />}
            label="Live Tracking"
          />
        </nav>

        <div className="p-4 border-t border-borderMain/50 space-y-4">
           {/* Role Switcher */}
           <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-inputBg/50 border border-borderMain/50">
             <div className="flex items-center gap-2 text-sm text-muted">
                <Users size={16} />
                <span className="text-xs font-bold uppercase">Role</span>
             </div>
             <select 
                value={role} 
                onChange={(e) => setRole(e.target.value)}
                className="bg-transparent text-xs font-bold text-accent outline-none text-right cursor-pointer dark:bg-inputBg"
             >
                <option className="dark:bg-darker">Shipper</option>
                <option className="dark:bg-darker">Carrier</option>
                <option className="dark:bg-darker">Recipient</option>
             </select>
           </div>

           {/* Wallet Button */}
           <button 
             onClick={handleWalletConnect}
             className={`w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-bold transition-all ${
                 walletConnected 
                 ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' 
                 : 'bg-primary text-white hover:bg-primary/90 shadow-lg shadow-primary/20'
             }`}
           >
             <Wallet size={16} />
             {walletConnected ? '0x71C...9A2' : 'Connect Wallet'}
           </button>

          <button 
            onClick={toggleTheme}
            className="w-full flex items-center justify-between px-4 py-2.5 rounded-lg bg-inputBg border border-borderMain/50 text-muted hover:text-body transition-all hover:border-accent/30 text-sm group"
          >
            <span className="flex items-center gap-2">
              {isDark ? <Moon size={16} className="group-hover:text-accent transition-colors" /> : <Sun size={16} className="group-hover:text-amber-500 transition-colors" />}
              {isDark ? 'Dark Mode' : 'Light Mode'}
            </span>
          </button>
        </div>
      </aside>

      {/* Mobile Nav Top Bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 w-full bg-surface/90 backdrop-blur-md border-b border-borderMain z-50 px-4 py-3 flex justify-between items-center transition-colors duration-300 pt-[calc(env(safe-area-inset-top)+0.75rem)]">
         <div className="flex items-center space-x-2 text-accent">
            <Box size={24} />
            <h1 className="text-lg font-bold text-body">BlockLogistics</h1>
          </div>
          <div className="flex gap-4 items-center">
            <button onClick={toggleTheme} className="text-muted hover:text-body">
               {isDark ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            <button onClick={() => setMobileMenuOpen(true)} className="text-muted hover:text-accent transition-colors p-1">
               <Menu size={24} />
            </button>
          </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 pt-24 md:pt-8 overflow-y-auto min-h-screen">
        {children}
      </main>

      {/* Chat Widget */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pb-[env(safe-area-inset-bottom)]">
        {chatOpen && (
            <div className="mb-4 w-[90vw] md:w-96 bg-surface backdrop-blur-xl border border-borderMain rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-10 duration-300">
                <div className="p-4 border-b border-borderMain flex justify-between items-center bg-inputBg/50">
                    <h3 className="font-bold text-body flex items-center gap-2">
                        <MessageSquare size={16} className="text-accent" />
                        Supply Chain AI
                    </h3>
                    <button onClick={() => setChatOpen(false)} className="text-muted hover:text-body">
                        <X size={16} />
                    </button>
                </div>
                <div className="h-80 overflow-y-auto p-4 space-y-3 bg-surface/50">
                    {messages.map((m, i) => (
                        <div key={i} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[85%] rounded-xl p-3 text-sm ${
                                m.sender === 'user' 
                                ? 'bg-accent text-white rounded-br-none' 
                                : 'bg-inputBg text-body border border-borderMain rounded-bl-none'
                            }`}>
                                {m.text}
                            </div>
                        </div>
                    ))}
                    {chatLoading && (
                        <div className="flex justify-start">
                             <div className="bg-inputBg rounded-xl p-3 border border-borderMain rounded-bl-none">
                                <div className="flex gap-1">
                                    <span className="w-1.5 h-1.5 bg-muted rounded-full animate-bounce"></span>
                                    <span className="w-1.5 h-1.5 bg-muted rounded-full animate-bounce delay-100"></span>
                                    <span className="w-1.5 h-1.5 bg-muted rounded-full animate-bounce delay-200"></span>
                                </div>
                             </div>
                        </div>
                    )}
                    <div ref={chatEndRef}></div>
                </div>
                <div className="p-3 border-t border-borderMain bg-surface">
                    <div className="flex gap-2">
                        <input 
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                            placeholder="Ask about shipments..."
                            className="flex-1 bg-inputBg border border-borderMain rounded-lg px-3 py-2 text-sm text-body focus:border-accent outline-none"
                        />
                        <button 
                            onClick={handleSendMessage}
                            disabled={chatLoading}
                            className="p-2 bg-accent text-white rounded-lg hover:bg-accent/90 disabled:opacity-50"
                        >
                            <Send size={18} />
                        </button>
                    </div>
                </div>
            </div>
        )}
        <button 
            onClick={() => setChatOpen(!chatOpen)}
            className="w-14 h-14 rounded-full bg-gradient-to-r from-primary to-accent text-white shadow-lg shadow-primary/30 flex items-center justify-center hover:scale-105 transition-transform active:scale-95"
        >
            {chatOpen ? <X size={24} /> : <MessageSquare size={24} />}
        </button>
      </div>
    </div>
  );
};

const NavButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden ${
      active 
        ? 'text-white shadow-lg shadow-primary/25' 
        : 'text-muted hover:bg-inputBg hover:text-body'
    }`}
  >
    {active && (
      <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent opacity-100 z-0"></div>
    )}
    <span className="relative z-10 flex items-center gap-3">
      {React.cloneElement(icon as React.ReactElement<{ className?: string }>, { 
        className: active ? 'text-white' : 'group-hover:text-primary transition-colors' 
      })}
      <span className="font-medium">{label}</span>
    </span>
  </button>
);

export default Layout;