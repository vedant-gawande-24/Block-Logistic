import React, { useState } from 'react';
import { Block, ShipmentStatus } from '../types';
import { Link, MapPin, Hash, Clock, User, FileText, ChevronDown, ChevronUp, Thermometer } from 'lucide-react';

interface BlockViewerProps {
  block: Block;
  isLatest: boolean;
}

const BlockViewer: React.FC<BlockViewerProps> = ({ block, isLatest }) => {
  const [expanded, setExpanded] = useState(isLatest);

  const getStatusColor = (s: ShipmentStatus) => {
    switch (s) {
      case ShipmentStatus.CREATED: return 'text-blue-500';
      case ShipmentStatus.DELIVERED: return 'text-emerald-500';
      case ShipmentStatus.EXCEPTION: return 'text-red-500';
      default: return 'text-amber-500';
    }
  };

  return (
    <div className="relative pl-10 pb-8 last:pb-0">
      {/* Connecting Line */}
      <div className="absolute left-[11px] top-6 bottom-0 w-0.5 bg-borderMain last:hidden"></div>

      {/* Node Dot */}
      <div className={`absolute left-0 top-6 -mt-1.5 w-6 h-6 rounded-full border-4 flex items-center justify-center z-10 bg-surface transition-all duration-300 ${
        isLatest 
          ? 'border-accent shadow-[0_0_15px_rgba(34,211,238,0.4)] scale-110' 
          : 'border-borderMain'
      }`}>
        <div className={`w-2 h-2 rounded-full ${isLatest ? 'bg-accent animate-pulse' : 'bg-muted'}`}></div>
      </div>

      <div 
        className={`relative group bg-surface border ${isLatest ? 'border-accent/40 shadow-lg shadow-accent/5' : 'border-borderMain'} rounded-2xl p-5 transition-all duration-200 hover:border-accent/30 hover:shadow-md`}
      >
        <div 
          className="flex justify-between items-start cursor-pointer select-none"
          onClick={() => setExpanded(!expanded)}
        >
          <div>
            <div className="flex items-center gap-3 mb-1.5">
              <span className="bg-inputBg border border-borderMain text-muted text-[10px] px-2 py-0.5 rounded-full font-mono font-bold tracking-wider uppercase">Block #{block.index}</span>
              <h4 className={`font-bold tracking-tight ${getStatusColor(block.data.status)}`}>{block.data.status.replace('_', ' ')}</h4>
            </div>
            <p className="text-xs text-muted flex items-center gap-1.5 font-medium">
              <Clock size={12} /> 
              {new Date(block.timestamp).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}
            </p>
          </div>
          <button className={`text-muted hover:text-body p-1 rounded-full hover:bg-inputBg transition-all ${expanded ? 'rotate-180' : ''}`}>
             <ChevronDown size={20} />
          </button>
        </div>

        {expanded && (
          <div className="mt-4 space-y-4 pt-4 border-t border-borderMain/50 animate-in slide-in-from-top-2 duration-200">
            {/* Metadata Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2.5 text-body bg-inputBg/50 p-2 rounded-lg">
                <MapPin size={16} className="text-primary" />
                <span className="font-medium">{block.data.location}</span>
              </div>
              <div className="flex items-center gap-2.5 text-body bg-inputBg/50 p-2 rounded-lg">
                <User size={16} className="text-accent" />
                <span>Handler: <span className="font-medium">{block.data.handler}</span></span>
              </div>
              {(block.data.temperature !== undefined) && (
                <div className="flex items-center gap-2.5 text-body bg-inputBg/50 p-2 rounded-lg">
                   <Thermometer size={16} className={block.data.temperature > 30 ? 'text-red-500' : 'text-emerald-500'} />
                   <span className="text-muted">Temp:</span>
                   <span className={`font-mono font-bold ${block.data.temperature > 30 ? 'text-red-500' : 'text-emerald-500'}`}>
                     {block.data.temperature}°C
                   </span>
                </div>
              )}
            </div>

            {/* Notes */}
            {block.data.notes && (
              <div className="bg-gradient-to-r from-inputBg to-transparent p-3 rounded-lg border-l-2 border-accent/50 flex gap-3">
                <FileText size={16} className="text-muted mt-0.5 shrink-0" />
                <p className="text-sm text-muted italic">"{block.data.notes}"</p>
              </div>
            )}

            {/* Hash Data */}
            <div className="space-y-2 pt-2">
               <div className="space-y-1">
                 <div className="flex items-center gap-1.5">
                   <Link size={12} className="text-muted" />
                   <span className="text-[10px] text-muted uppercase font-bold tracking-wider">Prev Hash</span>
                 </div>
                 <p className="font-mono text-[10px] text-muted/70 truncate bg-darker p-2 rounded border border-borderMain">
                   {block.previousHash}
                 </p>
               </div>

               <div className="space-y-1">
                 <div className="flex items-center gap-1.5">
                   <Hash size={12} className="text-accent" />
                   <span className="text-[10px] text-accent uppercase font-bold tracking-wider">Current Hash</span>
                 </div>
                 <p className="font-mono text-[10px] text-body truncate bg-darker p-2 rounded border border-accent/30 shadow-inner">
                   {block.hash}
                 </p>
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlockViewer;