export enum ShipmentStatus {
  CREATED = 'CREATED',
  PICKED_UP = 'PICKED_UP',
  IN_TRANSIT = 'IN_TRANSIT',
  CUSTOMS_CLEARANCE = 'CUSTOMS_CLEARANCE',
  DELIVERED = 'DELIVERED',
  EXCEPTION = 'EXCEPTION'
}

export interface BlockData {
  shipmentId: string;
  timestamp: number;
  status: ShipmentStatus;
  location: string;
  notes: string;
  handler: string; // E.g., "Carrier A", "Customs"
  temperature?: number; // IoT sensor data simulation
  humidity?: number;
  imageUrl?: string; // Base64 or URL for visual proof
}

export interface Block {
  index: number;
  timestamp: number;
  data: BlockData;
  previousHash: string;
  hash: string;
  nonce: number;
}

export interface Shipment {
  id: string;
  origin: string;
  destination: string;
  recipient: string;
  itemDescription: string;
  estimatedValue: number;
  createdAt: number;
  blocks: Block[]; // The local chain for this shipment
}

export type AnalysisResult = {
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  summary: string;
  suggestions: string[];
};