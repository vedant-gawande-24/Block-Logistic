import React, { useState } from 'react';
import { createShipment } from '../services/blockchainService';
import { Truck, Package, MapPin, IndianRupee, User, Info, UploadCloud, FileSpreadsheet } from 'lucide-react';

const CreateShipment: React.FC<{ onNavigate: (page: string, id?: string) => void }> = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    origin: '',
    destination: '',
    recipient: '',
    description: '',
    value: 0
  });

  const [activeTab, setActiveTab] = useState<'single' | 'bulk'>('single');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newShipment = createShipment(
      formData.origin,
      formData.destination,
      formData.recipient,
      formData.description,
      formData.value
    );
    // Redirect to tracking page
    onNavigate('tracking', newShipment.id);
  };

  const handleBulkUpload = () => {
      // Simulation
      alert("Bulk Upload Simulation: 5 Shipments processed from CSV.");
      onNavigate('dashboard');
  };

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-8 text-center md:text-left">
        <h2 className="text-3xl font-bold text-body mb-2 tracking-tight">Create New Shipment</h2>
        <p className="text-muted">Mint a new digital twin for your physical asset. This will initialize a new smart contract on the chain.</p>
      </div>

      <div className="flex gap-4 mb-6">
        <button 
            onClick={() => setActiveTab('single')}
            className={`flex-1 py-3 rounded-xl font-bold border ${activeTab === 'single' ? 'bg-surface border-accent text-accent shadow-lg shadow-accent/5' : 'bg-inputBg border-transparent text-muted hover:text-body'}`}
        >
            Single Entry
        </button>
        <button 
            onClick={() => setActiveTab('bulk')}
            className={`flex-1 py-3 rounded-xl font-bold border ${activeTab === 'bulk' ? 'bg-surface border-accent text-accent shadow-lg shadow-accent/5' : 'bg-inputBg border-transparent text-muted hover:text-body'}`}
        >
            Bulk Upload (CSV)
        </button>
      </div>

      {activeTab === 'single' ? (
      <form onSubmit={handleSubmit} className="bg-surface backdrop-blur-md rounded-2xl border border-borderMain p-8 shadow-xl relative overflow-hidden">
        {/* Decorative background element */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-accent/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <InputGroup 
            label="Origin Location" 
            icon={<MapPin size={18} />} 
            value={formData.origin}
            onChange={(v) => setFormData({...formData, origin: v})}
            placeholder="e.g. Mumbai, Warehouse A"
            required
            helper="Starting point of the chain of custody."
          />
          <InputGroup 
            label="Destination" 
            icon={<MapPin size={18} />} 
            value={formData.destination}
            onChange={(v) => setFormData({...formData, destination: v})}
            placeholder="e.g. Los Angeles, Port 4"
            required
            helper="Final delivery point."
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <InputGroup 
            label="Recipient Name" 
            icon={<User size={18} />} 
            value={formData.recipient}
            onChange={(v) => setFormData({...formData, recipient: v})}
            placeholder="e.g. Ship Mart Logistics"
            required
            helper="Authorized party to sign off delivery."
          />
          <InputGroup 
            label="Declared Value (INR)" 
            icon={<IndianRupee size={18} />} 
            type="number"
            value={formData.value}
            onChange={(v) => setFormData({...formData, value: Number(v)})}
            placeholder="0.00"
            required
            helper="Used for insurance smart contracts."
          />
        </div>

        <div className="mb-10">
           <label className="block text-sm font-bold text-body mb-2 ml-1">Item Description</label>
           <div className="relative group">
             <div className="absolute top-4 left-4 text-muted group-focus-within:text-accent transition-colors">
               <Package size={20} />
             </div>
             <textarea 
               value={formData.description}
               onChange={(e) => setFormData({...formData, description: e.target.value})}
               className="w-full bg-white dark:bg-inputBg border border-borderMain rounded-xl py-4 pl-12 pr-4 text-body focus:outline-none focus:border-accent focus:ring-4 focus:ring-accent/10 transition-all h-32 resize-none shadow-inner"
               placeholder="Detailed description of goods (e.g. 500 units of Electronics)..."
               required
             />
           </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-6 border-t border-borderMain/50">
          <div className="flex items-start gap-3 bg-blue-500/5 border border-blue-500/10 p-3 rounded-xl text-sm max-w-md">
            <Info size={18} className="text-blue-500 shrink-0 mt-0.5" />
            <div className="text-muted">
              <strong className="block text-blue-600 dark:text-blue-400 mb-0.5">Gas Fee Estimation</strong>
              This transaction will cost approximately <span className="font-mono text-body">0.004 ETH</span>.
            </div>
          </div>

          <div className="flex gap-4 w-full md:w-auto">
            <button 
              type="button" 
              onClick={() => onNavigate('dashboard')}
              className="flex-1 md:flex-none px-6 py-3 rounded-xl text-muted font-medium hover:text-body hover:bg-inputBg transition-colors"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="flex-1 md:flex-none bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg shadow-primary/25 flex items-center justify-center gap-2 transform active:scale-95"
            >
              <Truck size={20} />
              Initialize Contract
            </button>
          </div>
        </div>
      </form>
      ) : (
          <div className="bg-surface backdrop-blur-md rounded-2xl border border-borderMain p-12 shadow-xl flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 bg-inputBg rounded-full flex items-center justify-center mb-6 border border-borderMain">
                  <FileSpreadsheet size={40} className="text-accent" />
              </div>
              <h3 className="text-xl font-bold text-body mb-2">Upload CSV Manifest</h3>
              <p className="text-muted max-w-md mb-8">Drag and drop your shipment manifest file here. Supported formats: .csv, .xls. Maximum size: 5MB.</p>
              
              <button 
                onClick={handleBulkUpload}
                className="bg-accent text-white px-8 py-3 rounded-xl font-bold hover:bg-accent/90 transition-colors flex items-center gap-2"
              >
                  <UploadCloud size={20} />
                  Select File
              </button>
              <p className="mt-4 text-xs text-muted cursor-pointer hover:underline">Download Template</p>
          </div>
      )}
    </div>
  );
};

const InputGroup = ({ label, icon, value, onChange, type = "text", placeholder, required, helper }: any) => (
  <div className="group">
    <label className="block text-sm font-bold text-body mb-2 ml-1 flex justify-between">
      {label}
    </label>
    <div className="relative">
      <div className="absolute top-1/2 -translate-y-1/2 left-4 text-muted group-focus-within:text-accent transition-colors">
        {icon}
      </div>
      <input 
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-white dark:bg-inputBg border border-borderMain rounded-xl py-3 pl-12 pr-4 text-body focus:outline-none focus:border-accent focus:ring-4 focus:ring-accent/10 transition-all shadow-sm"
        placeholder={placeholder}
        required={required}
      />
    </div>
    {helper && <p className="text-xs text-muted mt-1.5 ml-1">{helper}</p>}
  </div>
);

export default CreateShipment;