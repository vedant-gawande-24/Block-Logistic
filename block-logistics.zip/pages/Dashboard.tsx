import React, { useEffect, useState } from 'react';
import { getShipments } from '../services/blockchainService';
import { Shipment, ShipmentStatus } from '../types';
import { Box, ShieldCheck, TrendingUp, AlertCircle, ArrowUpRight } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const Dashboard: React.FC<{ onNavigate: (page: string, id?: string) => void }> = ({ onNavigate }) => {
  const [shipments, setShipments] = useState<Shipment[]>([]);

  useEffect(() => {
    setShipments(getShipments());
  }, []);

  const stats = {
    total: shipments.length,
    active: shipments.filter(s => {
        const status = s.blocks[s.blocks.length - 1].data.status;
        return status !== ShipmentStatus.DELIVERED && status !== ShipmentStatus.EXCEPTION;
    }).length,
    delivered: shipments.filter(s => s.blocks[s.blocks.length - 1].data.status === ShipmentStatus.DELIVERED).length,
    exceptions: shipments.filter(s => s.blocks[s.blocks.length - 1].data.status === ShipmentStatus.EXCEPTION).length,
  };

  const chartData = [
    { name: 'Active', value: stats.active, color: '#3b82f6' },
    { name: 'Delivered', value: stats.delivered, color: '#10b981' },
    { name: 'Exception', value: stats.exceptions, color: '#f87171' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
          <h2 className="text-3xl font-bold text-body mb-2 tracking-tight">Network Overview</h2>
          <p className="text-muted max-w-xl">Real-time supply chain metrics managed by Ethereum Smart Contracts. Monitor your assets with immutable transparency.</p>
        </div>
        <button 
            onClick={() => onNavigate('create')}
            className="bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white px-6 py-3 rounded-xl font-medium transition-all shadow-lg shadow-primary/20 hover:shadow-primary/30 active:scale-95 flex items-center gap-2"
        >
            <Box size={18} />
            <span>New Shipment</span>
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Shipments" 
          value={stats.total} 
          icon={<Box size={24} className="text-white" />} 
          gradient="from-blue-500 to-blue-600"
          trend="+12%"
        />
        <StatCard 
          title="In Transit" 
          value={stats.active} 
          icon={<TrendingUp size={24} className="text-white" />} 
          gradient="from-amber-500 to-orange-600"
          trend="+5%"
        />
        <StatCard 
          title="Delivered" 
          value={stats.delivered} 
          icon={<ShieldCheck size={24} className="text-white" />} 
          gradient="from-emerald-500 to-teal-600"
          trend="+24%"
        />
        <StatCard 
          title="Alerts" 
          value={stats.exceptions} 
          icon={<AlertCircle size={24} className="text-white" />} 
          gradient="from-red-500 to-rose-600"
          trend="-2%"
          isNegative
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity List */}
        <div className="lg:col-span-2 bg-surface backdrop-blur-md rounded-2xl border border-borderMain p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-body">Recent Transactions</h3>
            <button className="text-xs text-primary hover:text-accent font-medium">View All</button>
          </div>
          
          <div className="space-y-3">
            {shipments.length === 0 && (
              <div className="text-center py-10 text-muted bg-inputBg/50 rounded-xl border border-dashed border-borderMain">
                No shipments found on chain. Create one to start.
              </div>
            )}
            {shipments.slice().reverse().slice(0, 5).map(shipment => {
               const latestBlock = shipment.blocks[shipment.blocks.length - 1];
               return (
                 <div 
                    key={shipment.id} 
                    onClick={() => onNavigate('tracking', shipment.id)}
                    className="group flex items-center justify-between p-4 bg-surfaceHighlight hover:bg-inputBg border border-borderMain/50 hover:border-accent/50 rounded-xl cursor-pointer transition-all duration-200"
                 >
                   <div className="flex items-center gap-4">
                     <div className="w-12 h-12 rounded-xl bg-inputBg border border-borderMain flex items-center justify-center text-muted group-hover:text-primary group-hover:bg-primary/10 transition-colors">
                       <Box size={22} />
                     </div>
                     <div>
                       <div className="font-mono text-sm text-primary font-bold tracking-tight mb-0.5">{shipment.id}</div>
                       <div className="text-sm text-body font-medium">{shipment.itemDescription}</div>
                     </div>
                   </div>
                   <div className="text-right">
                      <StatusBadge status={latestBlock.data.status} />
                      <div className="text-xs text-muted font-mono mt-1.5 opacity-70">
                        {new Date(latestBlock.timestamp).toLocaleTimeString()}
                      </div>
                   </div>
                 </div>
               );
            })}
          </div>
        </div>

        {/* Analytics Chart */}
        <div className="bg-surface backdrop-blur-md rounded-2xl border border-borderMain p-6 flex flex-col shadow-sm">
            <h3 className="text-lg font-semibold text-body mb-2">Status Distribution</h3>
            <p className="text-sm text-muted mb-6">Current breakdown of active fleet.</p>
            
            <div className="flex-1 min-h-[200px] relative">
                {chartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                          data={chartData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={85}
                          paddingAngle={4}
                          dataKey="value"
                          stroke="none"
                        >
                        {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                        </Pie>
                        <Tooltip 
                            contentStyle={{ 
                              backgroundColor: 'var(--color-surfaceHighlight)', 
                              borderColor: 'var(--border-main)', 
                              borderRadius: '12px',
                              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                              color: 'var(--text-body)' 
                            }}
                            itemStyle={{ color: 'var(--text-body)' }}
                            cursor={false}
                        />
                    </PieChart>
                    </ResponsiveContainer>
                ) : (
                    <div className="h-full flex items-center justify-center text-muted bg-inputBg/30 rounded-full aspect-square mx-auto w-3/4">
                      No data
                    </div>
                )}
                {/* Center text for Donut Chart */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="text-center">
                    <span className="text-2xl font-bold text-body">{stats.total}</span>
                    <span className="block text-xs text-muted uppercase">Total</span>
                  </div>
                </div>
            </div>
            
            <div className="mt-6 space-y-3">
                {chartData.map(d => (
                    <div key={d.name} className="flex items-center justify-between text-sm p-2 rounded-lg hover:bg-inputBg/50 transition-colors">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }}></div>
                          <span className="text-muted">{d.name}</span>
                        </div>
                        <span className="font-mono font-medium">{d.value}</span>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, gradient, trend, isNegative }: { title: string, value: number, icon: React.ReactNode, gradient: string, trend: string, isNegative?: boolean }) => (
  <div className="relative overflow-hidden bg-surface backdrop-blur-md p-6 rounded-2xl border border-borderMain shadow-sm group hover:border-accent/30 transition-all duration-300">
    <div className="flex justify-between items-start">
      <div>
        <p className="text-muted text-sm font-medium mb-1">{title}</p>
        <p className="text-3xl font-bold text-body tracking-tight">{value}</p>
      </div>
      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-300`}>
        {icon}
      </div>
    </div>
    <div className="mt-4 flex items-center gap-1 text-xs font-medium">
      <span className={`${isNegative ? 'text-rose-500' : 'text-emerald-500'} flex items-center gap-0.5`}>
        {isNegative ? <AlertCircle size={12} /> : <ArrowUpRight size={12} />}
        {trend}
      </span>
      <span className="text-muted opacity-60">vs last month</span>
    </div>
  </div>
);

const StatusBadge = ({ status }: { status: ShipmentStatus }) => {
  const styles = {
    [ShipmentStatus.CREATED]: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    [ShipmentStatus.PICKED_UP]: 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20',
    [ShipmentStatus.IN_TRANSIT]: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    [ShipmentStatus.CUSTOMS_CLEARANCE]: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
    [ShipmentStatus.DELIVERED]: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    [ShipmentStatus.EXCEPTION]: 'bg-red-500/10 text-red-500 border-red-500/20',
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border ${styles[status] || styles[ShipmentStatus.CREATED]}`}>
      {status.replace('_', ' ')}
    </span>
  );
};

export default Dashboard;