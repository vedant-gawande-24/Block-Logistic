import React, { useEffect, useState, useRef } from 'react';
import { getShipments, addEventToShipment } from '../services/blockchainService';
import { analyzeShipmentChain, generateSmartContractSummary, analyzeImageCondition } from '../services/geminiService';
import { Shipment, ShipmentStatus, AnalysisResult, Block } from '../types';
import BlockViewer from '../components/BlockViewer';
import { Search, PlusCircle, BrainCircuit, Code, RefreshCcw, ShieldAlert, CheckCircle, Package, Camera, FileText, QrCode, Map, Activity, Download } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface TrackingProps {
  shipmentId?: string;
}

const Tracking: React.FC<TrackingProps> = ({ shipmentId }) => {
  const [searchTerm, setSearchTerm] = useState(shipmentId || '');
  const [currentShipment, setCurrentShipment] = useState<Shipment | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'chain' | 'contract' | 'ai' | 'analytics' | 'docs'>('chain');
  const [showQR, setShowQR] = useState(false);
  
  // AI State
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [contractCode, setContractCode] = useState('');
  const [loadingContract, setLoadingContract] = useState(false);

  // New Event Form
  const [isAddingEvent, setIsAddingEvent] = useState(false);
  const [newEventData, setNewEventData] = useState({
    status: ShipmentStatus.IN_TRANSIT,
    location: '',
    handler: '',
    notes: '',
    temperature: 20
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageAnalysis, setImageAnalysis] = useState<string>('');
  const [analyzingImage, setAnalyzingImage] = useState(false);

  useEffect(() => {
    if (shipmentId) {
      handleSearch(shipmentId);
    }
  }, [shipmentId]);

  const handleSearch = (id: string) => {
    if (!id) return;
    setLoading(true);
    // Simulate network delay
    setTimeout(() => {
      const all = getShipments();
      const found = all.find(s => s.id === id);
      setCurrentShipment(found || null);
      setLoading(false);
      // Reset aux states
      setAnalysis(null);
      setContractCode('');
    }, 600);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      // Analyze Image
      setAnalyzingImage(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
          const base64String = (reader.result as string).split(',')[1];
          const result = await analyzeImageCondition(base64String, "Shipment Package");
          setImageAnalysis(result);
          setAnalyzingImage(false);
          // Auto fill notes if empty
          if(!newEventData.notes) {
              setNewEventData(prev => ({...prev, notes: `Visual Check: ${result}`}));
          }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShipment) return;
    
    // In a real app, upload image to IPFS and get URL
    const imageUrl = imageFile ? URL.createObjectURL(imageFile) : undefined;

    const updated = addEventToShipment(currentShipment.id, {
        ...newEventData,
        imageUrl
    });

    if (updated) {
      setCurrentShipment(updated);
      setIsAddingEvent(false);
      setImageFile(null);
      setImageAnalysis('');
    }
  };

  const runAIAnalysis = async () => {
    if (!currentShipment) return;
    setAnalyzing(true);
    const result = await analyzeShipmentChain(currentShipment);
    setAnalysis(result);
    setAnalyzing(false);
  };

  const loadSmartContract = async () => {
    if (!currentShipment) return;
    setLoadingContract(true);
    const code = await generateSmartContractSummary(currentShipment);
    setContractCode(code);
    setLoadingContract(false);
  };

  const exportPDF = async () => {
      if(!currentShipment) return;
      const element = document.getElementById('shipment-report');
      if(element) {
          const canvas = await html2canvas(element, { scale: 2 });
          const imgData = canvas.toDataURL('image/png');
          const pdf = new jsPDF('p', 'mm', 'a4');
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
          pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
          pdf.save(`BOL-${currentShipment.id}.pdf`);
      }
  };

  useEffect(() => {
    if (activeTab === 'contract' && !contractCode) {
      loadSmartContract();
    }
  }, [activeTab]);

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
      
      {/* Search Hero */}
      <div className="bg-surface backdrop-blur-xl p-8 rounded-2xl border border-borderMain shadow-lg flex flex-col md:flex-row gap-6 items-center justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
          <Package size={200} />
        </div>
        <div className="relative z-10 w-full md:w-auto flex-1">
          <h2 className="text-2xl font-bold text-body mb-2">Track & Trace</h2>
          <p className="text-muted mb-6">Enter a shipment ID to verify authenticity on the blockchain.</p>
          
          <div className="flex gap-2 max-w-xl">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={20} />
              <input 
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch(searchTerm)}
                placeholder="Enter Shipment ID (e.g. SHP-X92...)"
                className="w-full bg-white dark:bg-inputBg border border-borderMain hover:border-accent/50 focus:border-accent rounded-xl py-3 pl-12 pr-4 text-body outline-none transition-all shadow-inner font-mono"
              />
            </div>
            <button 
              onClick={() => handleSearch(searchTerm)}
              disabled={loading}
              className="bg-primary hover:bg-blue-600 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg shadow-primary/20 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {loading ? 'Scanning...' : 'Track'}
            </button>
          </div>
        </div>
      </div>

      {!loading && !currentShipment && searchTerm && (
         <div className="text-center py-20 bg-surface rounded-2xl border border-borderMain">
            <Package size={48} className="mx-auto text-muted mb-4 opacity-50" />
            <p className="text-muted">No shipment found with that ID on the local chain.</p>
         </div>
      )}

      {!loading && currentShipment && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          
          {/* Main Info Column */}
          <div className="xl:col-span-2 space-y-8" id="shipment-report">
             {/* Header Card */}
             <div className="bg-surface backdrop-blur-md rounded-2xl border border-borderMain p-6 shadow-sm relative">
               <div className="absolute top-6 right-6 flex gap-2">
                 <button onClick={() => setShowQR(!showQR)} className="p-2 bg-inputBg rounded-lg text-muted hover:text-accent border border-borderMain transition-colors">
                    <QrCode size={20} />
                 </button>
                 <button onClick={exportPDF} className="p-2 bg-inputBg rounded-lg text-muted hover:text-accent border border-borderMain transition-colors">
                    <Download size={20} />
                 </button>
               </div>

               <div className="flex flex-col md:flex-row justify-between items-start mb-6 gap-4 pr-24">
                 <div>
                    <h2 className="text-3xl font-bold text-body flex items-center gap-3 font-mono tracking-tight">
                        {currentShipment.id}
                        <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded-full border border-emerald-500/20 font-sans font-bold tracking-wider">VERIFIED</span>
                    </h2>
                    <p className="text-muted mt-2 text-lg">{currentShipment.itemDescription}</p>
                 </div>
                 <div className="text-right bg-inputBg/50 p-3 rounded-xl border border-borderMain">
                    <p className="text-xs text-muted uppercase font-bold tracking-wider mb-1">Estimated Value</p>
                    <p className="text-2xl text-emerald-500 font-mono font-bold">₹{currentShipment.estimatedValue.toLocaleString()}</p>
                 </div>
               </div>

               {showQR && (
                   <div className="mb-6 p-6 bg-white rounded-xl flex flex-col items-center justify-center animate-in fade-in slide-in-from-top-4">
                       <img 
                          src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${currentShipment.id}`} 
                          alt="QR Code" 
                          className="w-32 h-32 mb-2"
                       />
                       <p className="text-darker font-mono font-bold text-sm">{currentShipment.id}</p>
                   </div>
               )}
               
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-borderMain/50">
                 <div className="bg-inputBg/30 p-3 rounded-xl">
                    <p className="text-muted uppercase text-[10px] font-bold tracking-wider mb-1">Origin</p>
                    <p className="text-body font-medium">{currentShipment.origin}</p>
                 </div>
                 <div className="bg-inputBg/30 p-3 rounded-xl">
                    <p className="text-muted uppercase text-[10px] font-bold tracking-wider mb-1">Destination</p>
                    <p className="text-body font-medium">{currentShipment.destination}</p>
                 </div>
                 <div className="bg-inputBg/30 p-3 rounded-xl">
                    <p className="text-muted uppercase text-[10px] font-bold tracking-wider mb-1">Recipient</p>
                    <p className="text-body font-medium">{currentShipment.recipient}</p>
                 </div>
               </div>
             </div>

             {/* Digital Route Visualizer */}
             <div className="bg-surface rounded-2xl border border-borderMain p-6 overflow-hidden relative">
                 <h3 className="text-lg font-bold text-body mb-6 flex items-center gap-2">
                    <Map size={18} className="text-accent" /> Digital Route Map
                 </h3>
                 <div className="relative flex items-center justify-between px-10 py-10">
                    {/* The Line */}
                    <div className="absolute left-10 right-10 top-1/2 h-1 bg-borderMain rounded-full -z-10"></div>
                    <div 
                        className="absolute left-10 h-1 bg-accent rounded-full -z-10 transition-all duration-1000"
                        style={{ width: `${(currentShipment.blocks.length / (currentShipment.blocks.length + 1)) * 100}%` }}
                    ></div>

                    {/* Origin */}
                    <div className="flex flex-col items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-accent ring-4 ring-accent/20"></div>
                        <span className="text-xs font-bold text-body">{currentShipment.origin}</span>
                    </div>

                    {/* Hops */}
                    {currentShipment.blocks.slice(1).map((b, i) => (
                         <div key={i} className="flex flex-col items-center gap-2 animate-in zoom-in duration-500" style={{ animationDelay: `${i*100}ms`}}>
                            <div className="w-3 h-3 rounded-full bg-accent"></div>
                            <span className="text-[10px] text-muted max-w-[60px] text-center truncate">{b.data.location}</span>
                         </div>
                    ))}

                    {/* Dest (Ghost if not reached) */}
                    <div className="flex flex-col items-center gap-2">
                         <div className={`w-4 h-4 rounded-full border-2 ${currentShipment.blocks.some(b => b.data.status === ShipmentStatus.DELIVERED) ? 'bg-emerald-500 border-emerald-500' : 'bg-surface border-muted'}`}></div>
                         <span className="text-xs font-bold text-muted">{currentShipment.destination}</span>
                    </div>
                 </div>
             </div>

             {/* Chain Visualization */}
             <div>
                <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-bold text-body">Blockchain Ledger</h3>
                    <button 
                        onClick={() => setIsAddingEvent(!isAddingEvent)}
                        className="text-sm bg-surface hover:bg-inputBg text-body border border-borderMain px-4 py-2 rounded-lg flex items-center gap-2 transition-colors shadow-sm font-medium"
                    >
                        <PlusCircle size={16} className="text-accent" />
                        Update Status
                    </button>
                </div>

                {isAddingEvent && (
                    <form onSubmit={handleAddEvent} className="bg-surface border border-accent/30 p-6 rounded-2xl mb-8 animate-in slide-in-from-top-4 duration-300 shadow-xl shadow-accent/5">
                        <h4 className="text-body font-bold mb-4 flex items-center gap-2">
                          <span className="w-2 h-6 bg-accent rounded-full"></span>
                          Record New Event
                        </h4>
                        <div className="grid grid-cols-2 gap-4 mb-4">
                            <div className="space-y-1">
                              <label className="text-xs text-muted font-bold uppercase">Status</label>
                              <select 
                                  value={newEventData.status}
                                  onChange={e => setNewEventData({...newEventData, status: e.target.value as ShipmentStatus})}
                                  className="w-full bg-white dark:bg-inputBg border border-borderMain rounded-lg p-3 text-body text-sm outline-none focus:border-accent"
                              >
                                  {Object.values(ShipmentStatus).map(s => <option key={s} value={s}>{s}</option>)}
                              </select>
                            </div>
                            <div className="space-y-1">
                              <label className="text-xs text-muted font-bold uppercase">Location</label>
                              <input 
                                  placeholder="Current Location"
                                  value={newEventData.location}
                                  onChange={e => setNewEventData({...newEventData, location: e.target.value})}
                                  className="w-full bg-white dark:bg-inputBg border border-borderMain rounded-lg p-3 text-body text-sm outline-none focus:border-accent"
                                  required
                              />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 mb-4">
                            <input 
                                placeholder="Handler (e.g. Courier)"
                                value={newEventData.handler}
                                onChange={e => setNewEventData({...newEventData, handler: e.target.value})}
                                className="bg-white dark:bg-inputBg border border-borderMain rounded-lg p-3 text-body text-sm outline-none focus:border-accent"
                                required
                            />
                            <div className="flex gap-2">
                                <input 
                                    type="number"
                                    placeholder="Temp (°C)"
                                    value={newEventData.temperature}
                                    onChange={e => setNewEventData({...newEventData, temperature: Number(e.target.value)})}
                                    className="bg-white dark:bg-inputBg border border-borderMain rounded-lg p-3 text-body text-sm outline-none focus:border-accent flex-1"
                                />
                                <div className="relative">
                                    <input 
                                        type="file" 
                                        accept="image/*"
                                        onChange={handleImageUpload}
                                        className="absolute inset-0 opacity-0 cursor-pointer"
                                    />
                                    <div className={`h-full px-3 rounded-lg border border-borderMain flex items-center justify-center transition-colors ${imageFile ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30' : 'bg-inputBg hover:bg-inputBg/70'}`}>
                                        <Camera size={18} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        {analyzingImage && (
                            <div className="mb-4 text-xs text-accent flex items-center gap-2">
                                <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                                AI Visual Verification in progress...
                            </div>
                        )}
                        {imageAnalysis && (
                            <div className="mb-4 p-3 bg-accent/10 rounded-lg text-xs text-body border border-accent/20">
                                <strong>Gemini Vision:</strong> {imageAnalysis}
                            </div>
                        )}

                        <input 
                            placeholder="Notes/Observations"
                            value={newEventData.notes}
                            onChange={e => setNewEventData({...newEventData, notes: e.target.value})}
                            className="w-full bg-white dark:bg-inputBg border border-borderMain rounded-lg p-3 text-body text-sm mb-4 outline-none focus:border-accent"
                        />
                        <div className="flex justify-end gap-3">
                            <button type="button" onClick={() => setIsAddingEvent(false)} className="px-4 py-2 text-sm text-muted hover:text-body transition-colors">Cancel</button>
                            <button type="submit" className="px-6 py-2 text-sm bg-accent hover:bg-cyan-400 text-white dark:text-darker font-bold rounded-lg shadow-lg shadow-accent/20 transition-all">Mine Block</button>
                        </div>
                    </form>
                )}

                <div className="pl-2">
                    {currentShipment.blocks.slice().reverse().map((block, i) => (
                        <BlockViewer key={block.hash} block={block} isLatest={i === 0} />
                    ))}
                </div>
             </div>
          </div>

          {/* Sidebar / Tools */}
          <div className="space-y-6">
             <div className="bg-surface backdrop-blur-md rounded-2xl border border-borderMain overflow-hidden shadow-lg sticky top-24">
                <div className="flex p-1 bg-inputBg/50 m-2 rounded-xl overflow-x-auto no-scrollbar gap-1">
                    {['chain', 'ai', 'analytics', 'contract'].map((tab) => (
                        <button 
                            key={tab}
                            onClick={() => setActiveTab(tab as any)}
                            className={`flex-1 min-w-[60px] py-2 text-[10px] font-bold uppercase tracking-wide rounded-lg transition-all ${activeTab === tab ? 'bg-surface text-accent shadow-sm' : 'text-muted hover:text-body'}`}
                        >
                            {tab}
                        </button>
                    ))}
                </div>
                
                <div className="p-6 min-h-[400px]">
                    {activeTab === 'chain' && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-2">
                            <div className="p-5 bg-gradient-to-br from-inputBg to-surface rounded-xl border border-borderMain">
                                <h4 className="text-body font-bold mb-3 flex items-center gap-2">
                                    <ShieldAlert size={18} className="text-emerald-500" /> 
                                    Integrity Check
                                </h4>
                                <div className="space-y-3">
                                  <div className="flex justify-between text-sm">
                                    <span className="text-muted">Chain Status</span>
                                    <span className="text-emerald-500 font-mono font-bold">VALID</span>
                                  </div>
                                  <div className="flex justify-between text-sm">
                                    <span className="text-muted">Blocks Verified</span>
                                    <span className="text-body font-mono">{currentShipment.blocks.length}</span>
                                  </div>
                                  <div className="h-1 w-full bg-borderMain rounded-full overflow-hidden">
                                    <div className="h-full bg-emerald-500 w-full"></div>
                                  </div>
                                </div>
                            </div>
                            
                            <div className="p-5 bg-gradient-to-br from-inputBg to-surface rounded-xl border border-borderMain">
                                <h4 className="text-body font-bold mb-3 flex items-center gap-2">
                                    <CheckCircle size={18} className="text-blue-500" /> 
                                    Smart Contract Rules
                                </h4>
                                <ul className="space-y-2 text-sm">
                                  <li className="flex items-center gap-2 text-muted">
                                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                                    Max Temperature: 30°C
                                  </li>
                                  <li className="flex items-center gap-2 text-muted">
                                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                                    Signature Required
                                  </li>
                                </ul>
                            </div>
                        </div>
                    )}

                    {activeTab === 'analytics' && (
                        <div className="animate-in fade-in slide-in-from-right-2 h-full">
                            <h4 className="text-body font-bold mb-4 flex items-center gap-2">
                                <Activity size={18} className="text-accent" /> 
                                IoT Telemetry
                            </h4>
                            <div className="h-64 w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <AreaChart data={currentShipment.blocks.map((b, i) => ({ name: `B${i}`, temp: b.data.temperature || 20 }))}>
                                        <defs>
                                            <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%" stopColor="#0891b2" stopOpacity={0.8}/>
                                                <stop offset="95%" stopColor="#0891b2" stopOpacity={0}/>
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border-main)" opacity={0.3} />
                                        <XAxis dataKey="name" stroke="var(--text-muted)" fontSize={10} />
                                        <YAxis stroke="var(--text-muted)" fontSize={10} />
                                        <RechartsTooltip 
                                            contentStyle={{ backgroundColor: 'var(--color-surfaceHighlight)', border: '1px solid var(--border-main)' }}
                                            itemStyle={{ color: 'var(--text-body)' }}
                                        />
                                        <Area type="monotone" dataKey="temp" stroke="#0891b2" fillOpacity={1} fill="url(#colorTemp)" />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>
                            <p className="text-xs text-muted text-center mt-2">Temperature Fluctuation (°C)</p>
                            
                            <div className="mt-6 p-4 bg-inputBg rounded-xl border border-borderMain">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-xs font-bold text-muted uppercase">ETA Prediction</span>
                                    <span className="text-emerald-500 font-bold text-xs">On Time</span>
                                </div>
                                <div className="text-2xl font-mono text-body font-bold">~4h 12m</div>
                                <p className="text-[10px] text-muted mt-1">Calculated via AI based on block timestamps.</p>
                            </div>
                        </div>
                    )}

                    {activeTab === 'ai' && (
                        <div className="animate-in fade-in slide-in-from-right-2">
                             {!analysis ? (
                                <div className="text-center py-10 flex flex-col items-center">
                                    <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mb-4">
                                      <BrainCircuit size={32} className="text-accent" />
                                    </div>
                                    <h4 className="text-body font-bold mb-2">Gemini AI Auditor</h4>
                                    <p className="text-muted text-sm mb-6 max-w-xs">
                                        Scan the entire supply chain history for anomalies, risks, and inefficiency patterns using Google's GenAI.
                                    </p>
                                    <button 
                                        onClick={runAIAnalysis}
                                        disabled={analyzing}
                                        className="bg-accent hover:bg-cyan-400 text-white dark:text-darker font-bold px-6 py-3 rounded-xl w-full transition-all shadow-lg shadow-accent/20 disabled:opacity-50 disabled:cursor-wait"
                                    >
                                        {analyzing ? 'Analyzing Chain...' : 'Run Audit'}
                                    </button>
                                </div>
                             ) : (
                                <div className="space-y-5">
                                    <div className="flex items-center justify-between mb-2">
                                        <span className="text-sm font-bold text-muted uppercase tracking-wider">Risk Assessment</span>
                                        <span className={`px-3 py-1 rounded-full text-xs font-black tracking-widest ${
                                            analysis.riskLevel === 'LOW' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' :
                                            analysis.riskLevel === 'MEDIUM' ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20' :
                                            'bg-red-500 text-white shadow-lg shadow-red-500/20'
                                        }`}>{analysis.riskLevel}</span>
                                    </div>
                                    
                                    <div className="bg-inputBg p-4 rounded-xl border-l-4 border-accent">
                                        <p className="text-sm text-body leading-relaxed">"{analysis.summary}"</p>
                                    </div>

                                    <div>
                                        <p className="text-xs text-muted uppercase font-bold mb-3 flex items-center gap-2">
                                          <Code size={14} /> Optimization Suggestions
                                        </p>
                                        <ul className="space-y-3">
                                            {analysis.suggestions.map((s, i) => (
                                                <li key={i} className="text-sm text-muted bg-inputBg/50 p-3 rounded-lg border border-borderMain flex gap-3">
                                                  <span className="text-accent font-mono font-bold">0{i+1}.</span>
                                                  {s}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    
                                    <button 
                                        onClick={runAIAnalysis}
                                        className="text-xs text-accent hover:text-white font-medium flex items-center gap-2 mt-6 mx-auto hover:bg-accent/10 px-4 py-2 rounded-lg transition-colors"
                                    >
                                        <RefreshCcw size={12} /> Re-run Analysis
                                    </button>
                                </div>
                             )}
                        </div>
                    )}

                    {activeTab === 'contract' && (
                        <div className="h-full animate-in fade-in slide-in-from-right-2">
                            {loadingContract ? (
                                <div className="text-center py-20 text-muted flex flex-col items-center gap-3">
                                  <div className="w-6 h-6 border-2 border-accent border-t-transparent rounded-full animate-spin"></div>
                                  Reading Smart Contract...
                                </div>
                            ) : (
                                <div className="relative group">
                                    <div className="absolute top-0 right-0 p-2 bg-darker rounded-bl-xl border-l border-b border-borderMain">
                                      <Code size={14} className="text-emerald-500" />
                                    </div>
                                    <pre className="bg-darker p-4 rounded-xl text-[10px] md:text-xs font-mono text-emerald-400 overflow-x-auto whitespace-pre-wrap max-h-[400px] overflow-y-auto border border-borderMain shadow-inner">
                                        {contractCode}
                                    </pre>
                                </div>
                            )}
                        </div>
                    )}
                </div>
             </div>
          </div>

        </div>
      )}
    </div>
  );
};

export default Tracking;