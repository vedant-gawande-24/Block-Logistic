import React, { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import CreateShipment from './pages/CreateShipment';
import Tracking from './pages/Tracking';

const App: React.FC = () => {
  // Simple routing state
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedShipmentId, setSelectedShipmentId] = useState<string | undefined>(undefined);

  const handleNavigate = (page: string, id?: string) => {
    setCurrentPage(page);
    if (id) {
      setSelectedShipmentId(id);
    } else if (page !== 'tracking') {
      setSelectedShipmentId(undefined);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'create':
        return <CreateShipment onNavigate={handleNavigate} />;
      case 'tracking':
        return <Tracking shipmentId={selectedShipmentId} />;
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <Layout activePage={currentPage} onNavigate={handleNavigate}>
      {renderPage()}
    </Layout>
  );
};

export default App;