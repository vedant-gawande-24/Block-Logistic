import { GoogleGenAI, Type } from "@google/genai";
import { Block, Shipment } from "../types";

const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const analyzeShipmentChain = async (shipment: Shipment): Promise<any> => {
  const ai = getAIClient();
  
  // Format the chain for the AI
  const chainData = shipment.blocks.map(b => ({
    index: b.index,
    status: b.data.status,
    location: b.data.location,
    handler: b.data.handler,
    timestamp: new Date(b.timestamp).toISOString(),
    notes: b.data.notes,
    temp: b.data.temperature ? `${b.data.temperature}C` : 'N/A'
  }));

  const prompt = `
    You are an AI auditor for a blockchain-based logistics supply chain.
    Analyze the following shipment history JSON for:
    1. Security risks (e.g., unusual gaps in time, unexpected handlers).
    2. Efficiency (delays).
    3. Condition (temperature checks if available).
    
    Shipment Metadata:
    Origin: ${shipment.origin}
    Destination: ${shipment.destination}
    Value: ₹${shipment.estimatedValue}
    Item: ${shipment.itemDescription}

    Chain History:
    ${JSON.stringify(chainData, null, 2)}

    Return a JSON response strictly matching this schema:
    {
      "riskLevel": "LOW" | "MEDIUM" | "HIGH",
      "summary": "A short executive summary (max 30 words).",
      "suggestions": ["List of 2-3 specific recommendations or observations."]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskLevel: { type: Type.STRING, enum: ["LOW", "MEDIUM", "HIGH"] },
            summary: { type: Type.STRING },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    return {
      riskLevel: "UNKNOWN",
      summary: "AI analysis unavailable at this time.",
      suggestions: ["Check network connection.", "Verify API Key."]
    };
  }
};

export const generateSmartContractSummary = async (shipment: Shipment): Promise<string> => {
  const ai = getAIClient();
  const prompt = `
    Generate a pseudo-Solidity smart contract representation for this shipment.
    It should look like code but be a summary of the current state variables.
    
    Shipment ID: ${shipment.id}
    Owner: ${shipment.recipient}
    Current Status: ${shipment.blocks[shipment.blocks.length - 1].data.status}
    Value: ${shipment.estimatedValue}
    
    Do not use markdown backticks. Just raw text representing code.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt
    });
    return response.text || '// Error generating contract view';
  } catch (e) {
    return '// Error connecting to AI oracle';
  }
};

export const analyzeImageCondition = async (base64Image: string, description: string): Promise<string> => {
  const ai = getAIClient();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image
            }
          },
          {
            text: `Analyze this shipment image. The item is described as: "${description}". 
            Does the package look damaged? Are there dents, water marks, or open seals? 
            Return a 1 sentence status assessment.`
          }
        ]
      }
    });
    return response.text || "Image analysis complete.";
  } catch (e) {
    console.error(e);
    return "Could not analyze image condition.";
  }
};

export const chatWithSupplyChain = async (history: string[], question: string, context?: any): Promise<string> => {
  const ai = getAIClient();
  
  const systemContext = `You are a helpful supply chain assistant. 
  ${context ? `Current Shipment Context: ID ${context.id}, Item: ${context.itemDescription}, Status: ${context.status}` : ''}
  Answer questions about logistics, blockchain verification, or the specific shipment if context is provided.`;

  const prompt = `${systemContext}
  
  User Question: ${question}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt
    });
    return response.text || "I couldn't process that request.";
  } catch (e) {
    return "Service unavailable.";
  }
};