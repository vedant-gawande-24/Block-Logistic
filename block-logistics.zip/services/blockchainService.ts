import { Block, BlockData, Shipment, ShipmentStatus } from '../types';

// Simple hash function for simulation (DJB2 variant for visuals)
const calculateHash = (index: number, previousHash: string, timestamp: number, data: BlockData, nonce: number): string => {
  const str = index + previousHash + timestamp + JSON.stringify(data) + nonce;
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash) + str.charCodeAt(i); /* hash * 33 + c */
  }
  // Convert to hex-like string and pad
  const hex = (hash >>> 0).toString(16);
  return '0x' + hex.padStart(64, '0'); // Simulate 256-bit hash look
};

export const createGenesisBlock = (shipmentId: string, initialData: Partial<BlockData>): Block => {
  const data: BlockData = {
    shipmentId,
    timestamp: Date.now(),
    status: ShipmentStatus.CREATED,
    location: initialData.location || 'Origin',
    notes: 'Smart Contract Initialized',
    handler: 'System',
    ...initialData
  };
  
  const timestamp = Date.now();
  const hash = calculateHash(0, '0', timestamp, data, 0);

  return {
    index: 0,
    timestamp,
    data,
    previousHash: '0x0000000000000000000000000000000000000000000000000000000000000000',
    hash,
    nonce: 0
  };
};

export const mineBlock = (lastBlock: Block, data: BlockData): Block => {
  const index = lastBlock.index + 1;
  const timestamp = Date.now();
  const previousHash = lastBlock.hash;
  let nonce = 0;
  let hash = calculateHash(index, previousHash, timestamp, data, nonce);

  // Simulate "Proof of Work" (very easy difficulty for UI responsiveness)
  // In a real app, this happens on nodes. Here we just loop a bit to simulate work.
  while (!hash.endsWith('')) { // Difficulty 0 for instant demo, change to '0' or '00' for lag
    nonce++;
    hash = calculateHash(index, previousHash, timestamp, data, nonce);
  }

  return {
    index,
    timestamp,
    data,
    previousHash,
    hash,
    nonce
  };
};

// Local Storage Helper
const STORAGE_KEY = 'block_logistics_db';

export const getShipments = (): Shipment[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const saveShipment = (shipment: Shipment) => {
  const shipments = getShipments();
  const existingIndex = shipments.findIndex(s => s.id === shipment.id);
  if (existingIndex >= 0) {
    shipments[existingIndex] = shipment;
  } else {
    shipments.push(shipment);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(shipments));
};

export const createShipment = (
  origin: string, 
  destination: string, 
  recipient: string, 
  itemDescription: string,
  value: number
): Shipment => {
  const id = 'SHP-' + Math.random().toString(36).substr(2, 9).toUpperCase();
  const genesisBlock = createGenesisBlock(id, { location: origin, notes: `Shipment created: ${itemDescription}` });
  
  const newShipment: Shipment = {
    id,
    origin,
    destination,
    recipient,
    itemDescription,
    estimatedValue: value,
    createdAt: Date.now(),
    blocks: [genesisBlock]
  };
  
  saveShipment(newShipment);
  return newShipment;
};

export const addEventToShipment = (shipmentId: string, data: Omit<BlockData, 'shipmentId' | 'timestamp'>): Shipment | null => {
  const shipments = getShipments();
  const shipment = shipments.find(s => s.id === shipmentId);
  if (!shipment) return null;

  const lastBlock = shipment.blocks[shipment.blocks.length - 1];
  const fullData: BlockData = {
    ...data,
    shipmentId,
    timestamp: Date.now()
  };

  const newBlock = mineBlock(lastBlock, fullData);
  shipment.blocks.push(newBlock);
  saveShipment(shipment);
  return shipment;
};